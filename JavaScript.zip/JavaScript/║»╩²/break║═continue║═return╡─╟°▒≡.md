break :结束当前的循环体(如for、 while 、switch)
continue :跳出本次循环，继续执行下次循环（如for、while )
return:return :不仅可以退出循环，还能够返回return语句中的值，同时还可以结束当前的函数体内的代码

