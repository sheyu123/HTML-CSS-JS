window.addEventListener('load', function () {
    var vp = document.querySelector('.preview_img');
    var mask = document.querySelector('.masks');
    var big = document.querySelector('.bigs');

    //1.鼠标移入 preview_img 时 显示 mask 和 big
    vp.addEventListener('mouseover', function () {
        mask.style.display = 'block';
        big.style.display = 'block';
    })
    vp.addEventListener('mouseout', function () {
        mask.style.display = 'none'
        big.style.display = 'none';
    })

    //获得鼠标的坐标（鼠标到浏览器的坐标 减去 preview_img 距离浏览器的坐标 (注意是否有定位的父级元素)）
    vp.addEventListener('mousemove', function (e) {
        //由于父元素有定位，先拿到父元素距离浏览器的定位，再加上元素本身距离上一个父元素的定位
        var x = e.pageX - vp.parentNode.offsetLeft + vp.offsetLeft;
        var y = e.pageY - vp.parentNode.offsetTop + vp.offsetTop;

        var maxWidth = vp.offsetWidth - mask.offsetWidth; //左右最大距离
        var maxHight = vp.offsetHeight - mask.offsetHeight; //上下最大距离

        //将鼠标距离盒子的坐标赋值给遮罩层
        maskX = x - mask.offsetWidth / 2;
        maskY = y - mask.offsetHeight / 2;

        //限制遮罩层左右移动
        if (maskX <= 0) {
            maskX = 0;
        } else if (maskX >= maxWidth) {
            maskX = maxWidth;
        }

        //限制遮罩层上下移动
        if (maskY <= 0) {
            maskY = 0;
        } else if (maskY >= maxHight) {
            maskY = maxHight;
        }
        mask.style.left = maskX + 'px';
        mask.style.top = maskY + 'px';

        //计算大图片的最大移动距离
        var imgs = document.querySelector('.igs');
        var imgMax = imgs.offsetWidth - big.offsetWidth; //图片的最大距离减去大盒子的最大距离里
        var maskImgx = maskX * imgMax / maxWidth;
        var maskImgy = maskY * imgMax / maxWidth;

        imgs.style.left = -maskImgx + 'px';
        imgs.style.top = -maskImgy + 'px';

    })


    //tab栏目切换
    var li = document.querySelector('.detail_tab_list').querySelectorAll('li');
    var divs = document.querySelector('.detail_tab_con').querySelectorAll('div');
    //遍历ul 的子元素，给他添加点击事件
    for (var i = 0; i < li.length; i++) {
        //给每个li 一个自定义属性
        li[i].setAttribute('index', i);

        li[i].addEventListener('click', function () {
            //排他
            for (var i = 0; i < li.length; i++) {
                li[i].className = '';
            }
            this.className = 'detail_current';

            //获得自定义属性值
            var index = this.getAttribute('index');
            //排他
            for (var i = 0; i < divs.length; i++) {
                divs[i].style.display = 'none';
            }
            //根据点击返回的index 显示
            divs[index].style.display = 'block';
        });

    }
    li[0].className = 'detail_current'; //默认显示商品介绍样式
    divs[0].style.display = 'block'; //默认显示商品介绍

    //选择颜色
    var aColor = document.querySelector('.choose_color').querySelectorAll('a');
    var aColor1 = document.querySelector('.choose_version').querySelectorAll('a');
    var aColor2 = document.querySelector('.choose_version1').querySelectorAll('a');
    var aColor3 = document.querySelector('.choose_type').querySelectorAll('a');
    var aColor4 = document.querySelector('.choose_suits').querySelectorAll('a');


    //选择样式的方法封装
    function getCurrent(obj) {
        //遍历添加点击事件
        for (var i = 0; i < obj.length; i++) {
            obj[i].addEventListener('click', function () {
                for (var i = 0; i < obj.length; i++) {
                    obj[i].className = '';
                }
                this.className = 'current';
            });
        }
        obj[0].className = 'current'; //默认第一个选中ss
    }

    getCurrent(aColor); //选择颜色
    getCurrent(aColor1) //选择版本
    getCurrent(aColor2) //选择容量
    getCurrent(aColor3) //购买方式
    getCurrent(aColor4) //套装

    //加减
    var ipt = document.querySelector('.choose_amount').querySelector('input');
    var aNum = document.querySelector('.choose_amount').querySelectorAll('a');


    aNum[0].addEventListener('click', function () {
        if (ipt.value >= 1) {
            ipt.value++;
            
        }
    });

    aNum[1].addEventListener('click', function () {
        if (ipt.value > 1) {
            ipt.value--;
            aNum[1].style.cursor = '';
        }else{
            aNum[1].style.cursor = 'not-allowed';
        }
    });

    //鼠标移入时判断并更改鼠标样式
    aNum[1].addEventListener('mouseenter', function () {
        if (ipt.value > 1) {
            aNum[1].style.cursor = 'pointer';
           
        }else{
            aNum[1].style.cursor = 'not-allowed';
        }
    });

})      