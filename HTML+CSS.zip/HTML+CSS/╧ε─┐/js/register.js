window.addEventListener('load', function () {
    //获取事件源
    var ipt = document.querySelectorAll('.inp');
    var span = document.querySelectorAll('.error');
    console.log(ipt);

    for (var i = 0; i < ipt.length; i++) {
        ipt[i].addEventListener('blur', function () {
            Verification(ipt[0],span[0],11);
            Verification(ipt[1],span[1],6);
            Verification(ipt[2],span[2],11);
        });
    }

    //表单验证方法
    function Verification(arry,obj,length) {
        //判断是否长度
        if (arry.value.length == length) {
            obj.innerHTML = ' 您输入的数字正确';
            obj.style.color = 'green';
        } else {
            obj.innerHTML = ' 您输入的手机号码错误';
            obj.style.color = 'red';
        }
    }



})