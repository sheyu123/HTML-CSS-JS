window.addEventListener('load', function () {
    //获得事件源
    var focus = document.querySelector('.focus'); //大图层
    var arrow_l = document.querySelector('.arrow-l'); //左按钮
    var arrow_r = document.querySelector('.arrow-r'); //右按钮

    //鼠标移入大图层时显示左右按钮
    focus.addEventListener('mouseenter', function () {
        arrow_l.style.display = 'block';
        arrow_r.style.display = 'block';
        clearInterval(timer);
        timer = null; //清除定时变量
    });
    //鼠标移出大图层时隐藏左右按钮
    focus.addEventListener('mouseleave', function () {
        arrow_l.style.display = 'none';
        arrow_r.style.display = 'none';

        //鼠标离开启动定时器
        timer = setInterval(function () {
            arrow_r.click();//自动点击事件
        }, 2000);
    });

    //获得ul
    var ul = focus.querySelector('ul').children; //li
    var ol = document.querySelector('.circle'); //ol
    var uls = focus.querySelector('ul');//ul
    var foucusWidth = focus.offsetWidth;//获得focus的宽度
     

    for (var i = 0; i < ul.length; i++) {
        var lis = document.createElement('li'); //创建li 标签
        ol.appendChild(lis); //给ol 添加 子标签li

        //给每个i设置自定义属性
        lis.setAttribute('index', i);

        //给每个小圆点添加点击事件
        lis.addEventListener('mouseenter', function () {

            //循环排他思想
            for (var i = 0; i < ol.children.length; i++) {
                ol.children[i].className = '';
            }
            this.className = 'current';

            //将小圆点与图片移动距离绑定，（小圆点的索引号*focus的宽度）
            //获得当前小圆点的索引号，（点击索引号，移动的是ul）
            var index = this.getAttribute('index');

            num = index; //当我们点击了小圆圈，就把小圆圈的index 值赋值给按钮的计数器
            circle = index;//当我们点击了小圆圈，就把小圆圈的index 值赋值给小圆圈的计数器
            //调用animation中的方法 （移动的是ul）
            animation(uls, -index * foucusWidth);
        });
    }
    //第一个小圆圈添加白底
    ol.children[0].className = 'current';

    //克隆第一个li 并添加
    var first = uls.children[0].cloneNode(true);
    uls.appendChild(first); //因为是在生成li 的后面，所有不会加上小圆圈

    var num = 0; //计数器
    var circle = 0; //圆点计数器

   //创建节流阀
//    var flag = true;
    //右侧按钮赋值点击事件
    arrow_r.addEventListener('click', function () {
        
       /*  if (flag) {
            flag = false; */
            circle++;
            //当计数器等于小圆点的个数时，circle = 0;
            if (circle == ol.children.length) {
                circle = 0;
            }

            //清除所有小圆点样式
            for (var i = 0; i < ol.children.length; i++) {
                ol.children[i].className = '';
            }
            ol.children[circle].className = 'current'

            //判断图片的移动次数
            if (num == ul.length - 1) {
                uls.style.left = 0 + 'px';
                num = 0;
            }
            num++;
            
            animation(uls, -num * focus.offsetWidth, function(){
                flag = true;
            });
        /* } */

    })

    //左侧按钮赋值点击事件
    arrow_l.addEventListener('click', function () {

       /*  if (flag) {
            //返回false
            flag = false; */
            circle--;
            //当计数器等于小圆点的个数时，circle = 0;
            if (circle < 0) {
                circle = ol.children.length - 1;
            }

            //清除所有小圆点样式
            for (var i = 0; i < ol.children.length; i++) {
                ol.children[i].className = '';
            }
            ol.children[circle].className = 'current'

            //判断图片的移动次数
            if (num == 0) {
                num = uls.children.length - 1;
                uls.style.left = num * -foucusWidth + 'px';
            }
            num--;
            animation(uls, -num * foucusWidth, function () {
                //利用回调函数 限制点击速度
                flag = true;
            });
        /* } */

    })

    //定时器（2秒触发一次）
    var timer = setInterval(function () {
        arrow_r.click();//自动点击事件
    }, 2000);


    //键盘事件，按下s 键 input 获得光标
    var ipt = document.querySelector('.text');
    document.addEventListener('keyup',function(e){
        if(e.key === 's'){
            ipt.focus(); //输入框获得光标
        }
    })



})
